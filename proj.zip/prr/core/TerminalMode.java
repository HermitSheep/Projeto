package prr.core;

public enum TerminalMode {
  BUSY,
  IDLE,
  SILENCE,
  OFF
}
