package prr.core.exception;

public class cantEndComException extends Exception{
    public cantEndComException() {}
}
