package prr.core.exception;

public class CommunicationAlreadyPayedException extends Exception{
    public CommunicationAlreadyPayedException() {}
}
