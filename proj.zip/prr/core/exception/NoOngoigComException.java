package prr.core.exception;

public class NoOngoigComException extends Exception{
    public NoOngoigComException() {}
}
