package prr.app.exception;

public class DestinationTerminalOff {
    
}
