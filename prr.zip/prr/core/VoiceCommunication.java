package prr.core;

public class VoiceCommunication extends InteractiveCommunication{
  public VoiceCommunication() {
    //FIXME implement constructor
  }

  protected double computeCost(TariffPlan plan) {
    //FIXME implement method
  }

}
