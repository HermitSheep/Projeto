package prr.core;

public class Basic extends Terminal {
  public Basic(String id, Client client) {
    super(id, client);
  }

  
  public void makeVideoCall(Terminal to) {
    //FIXME implement method
  }

  protected void acceptVideoCall(Terminal to) {
    //FIXME implement method
  }
}
