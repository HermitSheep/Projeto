package prr.core;

public enum NotificationType {
  O2S,
  O2I,
  B2S,
  B2I
  }
