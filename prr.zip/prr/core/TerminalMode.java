package prr.core;

public enum TerminalMode {
  BUSY,
  ON,
  SILENSE,
  OFF
}
