package prr.core;

public abstract class InteractiveCommunication extends Communication{
  private int duration;

  protected int getSize() {
    //FIXME implement method
  }
}
