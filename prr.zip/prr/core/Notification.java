package prr.core;

public class Notification {
  private NotificationType _type;

  public Notification(NotificationType type) {
    _type = type;
  }

  public String toString() {
    //FIXME implement method
  }
}
