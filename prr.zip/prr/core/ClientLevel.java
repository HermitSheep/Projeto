package prr.core;

public enum ClientLevel {
  NORMAL,
  GOLD,
  PLATINUM
}
