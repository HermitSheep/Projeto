package prr.core;

public class VideoCommunication extends InteractiveCommunication{
  public VideoCommunication() {
    //FIXME implement constructor
  }

  protected double computeCost(TariffPlan plan) {
    //FIXME implement method
  }
}
