package prr.core;


public class Fancy extends Terminal {
  public Fancy(String id, Client client) {
    super(id, client);
  }

  public void makeVideoCall(Terminal to) {
    //FIXME implement method
  }

  protected void acceptVideoCall(Terminal to) {
    //FIXME implement method
  }
}
