package prr.core;

public class BasicPlan extends TarrifPlan{
  protected double computeCost(Parser.Client cl, TextCommunication com) {
    //FIXME implement method
  }

  protected double computeCost(Parser.Client cl, VoiceCommunication com) {
    //FIXME implement method
  }

  protected double computeCost(Parser.Client cl, VideoCommunication com){
    //FIXME implement method
  }
}
